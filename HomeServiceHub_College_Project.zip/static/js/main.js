document.addEventListener("DOMContentLoaded", () => {
  const menu = document.querySelector(".menu-toggle");
  const nav = document.querySelector(".nav-links");
  if (menu && nav) menu.addEventListener("click", () => nav.classList.toggle("nav-open"));

  document.querySelectorAll(".flash-close").forEach(button => {
    button.addEventListener("click", () => button.closest(".flash")?.remove());
  });

  const dateInput = document.querySelector('input[name="service_date"]');
  if (dateInput && !dateInput.min) {
    const today = new Date();
    const localDate = new Date(today.getTime() - today.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
    dateInput.min = localDate;
  }

  const checkout = document.getElementById("checkout-form");
  if (checkout) {
    checkout.addEventListener("submit", event => {
      const phone = checkout.querySelector('input[name="phone"]');
      if (phone && !/^\d{10}$/.test(phone.value.trim())) {
        event.preventDefault();
        phone.setCustomValidity("Enter a 10-digit mobile number.");
        phone.reportValidity();
      } else if (phone) {
        phone.setCustomValidity("");
      }
    });
  }
});
